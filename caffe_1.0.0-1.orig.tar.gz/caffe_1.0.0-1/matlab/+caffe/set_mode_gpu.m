function set_mode_gpu()
% set_mode_gpu()
%   set Caffe to GPU mode

caffe_('set_mode_gpu');

end
